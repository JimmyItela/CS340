# Example Python Code to Insert a Document 

# CRUD_Python_Module.py
from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter(object):
    """
    CRUD operations for the 'animals' collection in the 'aac' MongoDB database.
    Authentication is performed against the 'admin' database.
    """

    def __init__(
        self,
        username: str = "aacuser",
        password: str = "MyStrongPassword123", # using the same password as I created in last module
        host: str = "localhost",
        port: int = 27017,
        db_name: str = "aac",
        collection_name: str = "animals",
    ):
        """
        Initialize the MongoDB client, database, and collection handles.
        """
        # Build a connection string that authenticates against the admin DB
        uri = "mongodb://%s:%s@%s:%d/?authSource=admin" % (username, password, host, port)

        try:
            self.client = MongoClient(uri)
            self.database = self.client[db_name]
            self.collection = self.database[collection_name]
        except PyMongoError as e:
            # Re-raise as a plain Exception so it’s obvious in the notebook
            raise Exception(f"MongoDB connection failed: {e}")

    # --------------------------- C (Create) --------------------------- #
    def create(self, data: dict) -> bool:
        """
        Insert a single document into the collection.
        :param data: Non-empty dictionary representing a document.
        :return: True if the insert succeeded; False otherwise.
        """
        if data is None or not isinstance(data, dict) or len(data) == 0:
            raise Exception("Nothing to save; 'data' must be a non-empty dict.")

        try:
            result = self.collection.insert_one(data)
            return bool(result.inserted_id)
        except PyMongoError as e:
            raise Exception(f"Create operation failed: {e}")

    # ---------------------------- R (Read) --------------------------- #
    def read(self, query: dict):
        """
        Query documents using MongoDB's find(). Returns a list (possibly empty).
        :param query: Dictionary query. Pass {} to return all documents.
        :return: List of documents.
        """
        if query is None or not isinstance(query, dict):
            raise Exception("Query must be a dict (use {} to return all documents).")

        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except PyMongoError as e:
            raise Exception(f"Read operation failed: {e}")
            
    # ---------------------------------- U (Update) ---------------------------------- #
    def update(self, query: dict, new_values: dict, many=False):
        """
        Update document(s) in the collection.
        :param query: dictionary filter to match document(s)
        :param new_values: dictionary with fields to update, e.g., {"color": "Black"}
        :param many: if True, updates all matching documents
        :return: number of documents modified
        """
        if query is None or not isinstance(query, dict):
            raise Exception("Query must be a dictionary.")
        if new_values is None or not isinstance(new_values, dict):
            raise Exception("New values must be provided as a dictionary.")

        try:
            if many:
                result = self.collection.update_many(query, {"$set": new_values})
            else:
                result = self.collection.update_one(query, {"$set": new_values})
            return result.modified_count
        except Exception as e:
            raise Exception(f"Update operation failed: {e}")


    # ---------------------------------- D (Delete) ---------------------------------- #
    def delete(self, query: dict, many=False):
        """
        Delete document(s) from the collection.
        :param query: dictionary filter to match document(s)
        :param many: if True, deletes all matching documents
        :return: number of documents deleted
        """
        if query is None or not isinstance(query, dict):
            raise Exception("Query must be a dictionary.")

        try:
            if many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)
            return result.deleted_count
        except Exception as e:
            raise Exception(f"Delete operation failed: {e}")